library(testthat)
library(RCAS)

test_check("RCAS")
